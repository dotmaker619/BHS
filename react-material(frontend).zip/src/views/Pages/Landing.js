import React, {useState, useEffect} from "react";
import { connect } from 'react-redux';
import { Router, Route, Switch, Redirect, withRouter } from "react-router-dom";
// @material-ui/core components

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import NavPills from "components/NavPills/NavPills.js";
import LandingFooter  from "views/Components/LandingFooter";


const Landing = (user) => {
    return (
        <div>
           <LandingFooter />
        </div>
    );
}

const mapStateToProps = (state, ownProps) => ({
    user: state.auth.user
  })
  
  const mapDispatchToProps = ({

  })
  
  export default connect(mapStateToProps, mapDispatchToProps)(withRouter(Landing))