const ActionTypes = {
  signin: 'LOG_IN',
  signup: 'SIGN_UP',
  logout: 'LOG_OUT',
  recoverpass: 'RECOVER_PASS',
  miniActive: 'MINI_ACTIVE',
 }

export default ActionTypes;